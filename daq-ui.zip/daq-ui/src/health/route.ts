// daq-ui/src/app/health/route.ts
import { NextResponse } from "next/server";

export async function GET() {
    return NextResponse.json({ ok: true, service: "daq-ui" });
}